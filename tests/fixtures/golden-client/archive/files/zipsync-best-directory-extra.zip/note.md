---
id: AbCdEfGhIjKlMnOpQrStUv
date: 2026-11-02T10:00:00+00:00
tags: [beach]
media: [{ file: 001.jpg, kind: photo }]
---

A day at the beach. A day at the beach. A day at the beach.
